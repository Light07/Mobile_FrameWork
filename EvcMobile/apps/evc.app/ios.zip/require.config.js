require.config({
    "waitSeconds": 0,
    "baseUrl": "bower_components",
    "packages": [
        {
            "name": "jquery",
            "location": "jquery/dist",
            "main": "jquery"
        },
        {
            "name": "URI",
            "location": "uri.js/src",
            "main": "URI"
        }
    ],
    "map": {
        '*': {
            "less": "require-less/less",
            "css": "require-css/css",
            "fm/icelink": "fm/fm.icelink",
            "fm/icelink/webrtc": "fm/fm.icelink.webrtc",
            "fm/icelink/websync": "fm/fm.icelink.websync",
            "fm/websync": "fm/fm.websync",
            "fm/websync/chat": "fm/fm.websync.chat",
            "fm/websync/subscribers": "fm/fm.websync.subscribers",
            "evc15-fe-layout-manager": "evc15-fe-mobile-layout-manager",
            "evc15-fe-av-ui": "evc15-fe-av-mobile-ui",
            "notifications-provider": "evc15-fe-notifications-ui/providers/native/main",
            "resource-path-provider": "evc15-fe-renderer-ui/resourcePathProviders/native/main",
            "actions-handler": "../app/actionsHandler"
        }
    },
    "paths": {
        "text": "requirejs-plugins/lib/text",
        "image": "requirejs-plugins/src/image",
        "json": "requirejs-plugins/src/json",
        "propertyParser": "requirejs-plugins/src/propertyParser",
        "brolog": "evc15-fe-analytics/producers/logger/main",
        "postal": "postal.js/lib/postal",
        "lodash": "lodash/lodash",
        "ractive": "ractive/ractive",
        "fm": "evc15-fe-fm",
        "quill": "quill/dist/quill",
        "rv": "rv/rv",
        "fabric": "fabric/dist/fabric.require",
        "bootstrap.tooltip": "bootstrap/js/tooltip",
        "bootstrap.popover": "bootstrap/js/popover",
        "keypress": "Keypress/keypress",
        "jquery.awesome-cursor": "jquery-awesome-cursor/dist/jquery.awesome-cursor",
        "bowser": "bowser/bowser",
        "main": "../app/main",
        "evc15-fe-av-mobile-ui": "../dummies/av-mobile",
        "jsAvBridge": "../dummies/av-mobile/jsbridge_shim",
        "velocity": "velocity/velocity",
        "jquery.finger": "jquery.finger/dist/jquery.finger",
        "fastclick": "fastclick/lib/fastclick",
        "jsondiffpatch": "jsondiffpatch/public/build/jsondiffpatch",
        "punycode": "punycode/punycode"
    },
    "shim": {
        "bootstrap.tooltip": {
            "deps": ["jquery"]
        },
        "bootstrap.popover": {
            "deps": ["jquery", "bootstrap.tooltip"]
        },
        "velocity": {
            "deps": ["jquery"]
        }
    },
    "less": {
        "logLevel": 1
    }
});
